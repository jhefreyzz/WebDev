function AlertService() 
{ 
alert("We received your order. Thank you!"); 
} 
function AlertContact(){
alert("Thank you for sending your message.")
}